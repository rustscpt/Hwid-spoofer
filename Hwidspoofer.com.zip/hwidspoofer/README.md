# Rust-script-
Monolith.wtf (Cracked) 
this was not cracked by me
not responible for any actions 
